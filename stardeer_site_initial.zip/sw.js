
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open('stardeer-v1').then(cache => {
      return cache.addAll([
        './index.html',
        './assets/css/style.css',
        './assets/js/app.js'
      ]);
    })
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request).then(resp => {
      return resp || fetch(event.request);
    })
  );
});
